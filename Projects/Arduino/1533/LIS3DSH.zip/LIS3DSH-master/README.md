LIS3DSH
=======

LIS3DSH accelerometer Arduino library

Reworked library by Mike Kirkhart <mkirkhart@navigationsolutions.com> based on the L3G Library

https://github.com/pololu/L3G

