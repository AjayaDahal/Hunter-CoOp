### smt-soic.pretty ###

SOIC package

* 8,14,16 pins - Narrow (JEDEC MS-012AA)
* 16,18,20,24,28 pins - Wide (JEDEC MS-013) 
* 8 pins - Narrow w/ Exposed pad (JEDEC MS-012BA)
