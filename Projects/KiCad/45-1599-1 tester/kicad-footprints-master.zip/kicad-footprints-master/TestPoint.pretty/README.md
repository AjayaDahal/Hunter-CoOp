# Connectors_TestPoints.pretty
Footprints for and probe connection points
