### smt.pretty ###

SMT components

* Resistor (R-****)
    - 0603 (1608 metric)
    - 0805 (2012 metric)
    - 1206 (3216 metric)
    - 1210 (3225 metric)

* Capacitor (C-****)
    - 0603 (1608 metric)
    - 0805 (2012 metric)
    - 1206 (3216 metric)
    - 1210 (3225 metric)

* Polarized Capacitor (CPL-****)
    - 0603 (1608 metric)
    - 0805 (2012 metric)
    - 1206 (3216 metric)
    - 1210 (3225 metric)

* Diode
    - SOD-323
    - DO-214-AA

* Inductors
    - 10mm x 10mm 

* Ferrite
    - 0603 (1608 metric)
    - 0805 (2012 metric)
    - 1206 (3216 metric)
    - 1210 (3225 metric)

* LED
    - 5050 (WS2812x)
    - 0805
