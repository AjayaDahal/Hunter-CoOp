### crystals.pretty ###

* HC49UP (SMT)
