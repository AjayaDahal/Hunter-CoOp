### misc.pretty ###

* ACME Systems SOM
    - ARIA-G25

* LCD modules
    - OLED ER-OLED1602

* Mousebite patterns
    - single-31-small : 100 mil gap, for 31 mil(0.8mm) boards, one side
    - single-62-small : 100 mil gap, for 62 mil(1.6mm) boards, one side
    - double-31-small : 100 mil gap, for 31 mil(0.8mm) boards, both sides
    - double-62-small : 100 mil gap, for 62 mil(1.6mm) boards, both sides
