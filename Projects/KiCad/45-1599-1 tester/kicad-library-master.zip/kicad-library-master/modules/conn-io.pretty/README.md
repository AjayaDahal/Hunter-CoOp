### conn-io.pretty ###

* USB Jack (Type A)
    - Molex 48204
    - Molex 292303-1

* USB Jack (Type B mini)
    - Hirose UX60SC-MB-5ST

* RJ45 Jack
    - Molex 48025
    - Tyco 406549
    - Wurth 7498011122R 
