### smt-sot.pretty ###

SOT SMT packages

* SOT-143
* SOT-23
* SOT-23-5
* SOT-23-6
