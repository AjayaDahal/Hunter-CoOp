### conn-header.pretty ###

* Molex 2mm pitch - Male (Standard)
    - 2MM-HDR-M-2x** : Vertical, Through hole, Dual row (2 to 30 pos)
    - 2MM-HDR-M-1x** : Vertical, Through hole, Single row (1 to 15 pos)

* Molex 100mil pitch, Single Row w/ Friction lock
    - MOLEX-22-05-3**1 : KK-7478, Right angle, Through Hole - (1 to 15 pins)
    - MOLEX-22-23-2**1 : KK-6373, Vertical, Through Hole - (1 to 15 pins)
    
* 100mil pitch - Male (Standard)
    - HDR-M-1x** : Vertical, Through Hole, Single row (1 to 15 pos)
    - HDR-M-2x** : Vertical, Through Hole, Dual row (2 to 30 pos)

* Hirose DF3 series connectors (2mm pitch)
    - DF3A-**-2DSA  : single row, vertical through hole (2 to 15 pins)
    - DF3DZ-**-2VXX : single row, vertical smt (2 to 15 pins)

* Hirose DF13 series connectors (1.25mm pitch)
    - DF13A-**DP-1.25 : dual row, vertical smt (10,20,30,40 pins) 
