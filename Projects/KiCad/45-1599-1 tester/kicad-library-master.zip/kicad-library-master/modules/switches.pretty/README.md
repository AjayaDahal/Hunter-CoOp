### switches.pretty ###

* Tactile switches
    - Omron B3F-40XX, B3F-10XX, B3F-315X
