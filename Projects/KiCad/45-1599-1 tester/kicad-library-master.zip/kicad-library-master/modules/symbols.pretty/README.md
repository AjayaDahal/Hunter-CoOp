### symbols.pretty ###

* Open Hardware Logo (OSHW)
    - LOGO-OSHW-100 : 100mil wide
    - LOGO-OSHW-150 : 150mil wide
    - LOGO-OSHW-250 : 250mil wide
    - LOGO-OSHW-500 : 500mil wide

* Gauges
    - Gauge-X-100mm : 100mm gauge, X axis
    - Gauge-XY-100mm : 100mm gauge, Both axis

* Other symbols
    - Arrow 
    - Trash can