### conn-power.pretty ###

* DC Barrel Jack
    - CUI PJ-013C
    - CUI PJ-031CH
    - CUI P1J-021-SMT
  
