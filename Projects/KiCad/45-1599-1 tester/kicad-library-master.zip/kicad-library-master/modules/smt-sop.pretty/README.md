### smt-sop.pretty ###

SOP SMT packages

* SSOP : 14,16,20,24,28 pins - 5.3mm (JEDEC MO-150)
* MSOP : 8 pins - 3mm (JEDEC MO-187)
 
